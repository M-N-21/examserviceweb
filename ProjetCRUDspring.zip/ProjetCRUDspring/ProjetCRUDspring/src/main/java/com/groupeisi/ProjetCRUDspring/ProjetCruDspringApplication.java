package com.groupeisi.ProjetCRUDspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetCruDspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetCruDspringApplication.class, args);
	}

}
